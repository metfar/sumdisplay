# sumdisp 0.1a09 (revisión incremental)

Una herramienta de comodidad visual para XRandR (X11).

## Cambios en 0.1a09

- «Cargar perfil» muestra los perfiles definidos como selector nativo, sin pedir el nombre a ciegas: diálogo modal en sumTUI y lista desplazable en sumGUI.
- Vista reciente de escalas lógicas en tres secciones: **personalizadas usadas (MRU)**, **predefinidas usadas (MRU)** y **personalizadas definidas sin usar**. Las cabeceras y los separadores no son opciones aplicables.
- `sumdisp define-scale 1500x850` agrega una escala personalizada a la lista, **sin aplicarla**. Los perfiles existentes aportan asimismo definiciones personalizadas.
- «Mostrar catálogo» permanece desactivado inicialmente y ofrece la lista completa ordenada por tamaño; cambiar ese checkbox no aplica nada.
- `Default` equivale a la transformación XRandR 1:1. No se cambia el modo físico desde las interfaces ni al cargar perfiles.
- Los controles de gamma/brillo mantienen su rango y comportamiento anterior; brillo entre -5 y +5, como en la revisión del usuario.

## Uso

```bash
sumdisp --tui
sumdisp --gui
sumdisp define-scale 1500x850
sumdisp save lectura
sumdisp load lectura
```

Los perfiles se guardan en `~/.config/sumdisp/profiles/*.json`. El historial y las escalas personalizadas definidas se almacenan en `~/.config/sumdisp/config.json`, por máquina y salida.

## Pruebas

```bash
python3 test_resolution_history.py
python3 test_groups_profiles.py
```

Las pruebas son simuladas: no requieren monitor ni modifican XRandR. Las interfaces nativas requieren sumUI, sumTUI/sumGUI y sus dependencias, y deben verificarse manualmente en equipos reales.

## Limitaciones

- El ComboBox **editable con búsqueda** pertenece a la hoja de ruta común de sumUI/sumTUI/sumGUI, pero **aún no está integrado**. El selector actual de sumdisp es de selección.
- Las secciones de recientes preservan su estructura lógica. En TUI el control existente es un `Choice` horizontal y no un desplegable multicelda; se muestran títulos y separadores como entradas no seleccionables. En GUI aparecen en el desplegable existente.
- No se ha ejecutado prueba funcional GUI en un entorno de pantalla real.
