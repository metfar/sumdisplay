#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#pylint:disable=W0301
#
#  Copyright 2018- William Martinez Bas <metfar@gmail.com>
#  GPL-2.0-or-later
import importlib.machinery;
import importlib.util;
import pathlib;
import tempfile;

source = pathlib.Path(__file__).with_name("sumdisp");
loader = importlib.machinery.SourceFileLoader("sumdisp_groups_test", str(source));
spec = importlib.util.spec_from_loader(loader.name, loader);
sd = importlib.util.module_from_spec(spec);
loader.exec_module(sd);

with tempfile.TemporaryDirectory() as root:
    sd.CONFIG_DIR = pathlib.Path(root);
    sd.CONFIG_FILE = sd.CONFIG_DIR / "config.json";
    sd.PROFILES_DIR = sd.CONFIG_DIR / "profiles";
    output = {"name": "TEST-1", "mode": "1366x768", "modes": ["1366x768"], "primary": True};
    calls = [];
    sd.xrandr = lambda *args: calls.append(args) or "";
    sd.time.sleep = lambda _seconds: None;
    assert sd.profile_names(output) == [];
    config = sd.config_read();
    sd.define_custom(config, output, "1500x850");
    sd.define_custom(config, output, "1600x800");
    sd.config_write(config);
    sd.update(output, {"scale": "1600x800"});
    sd.update(output, {"scale": "1920x1080"});
    sd.update(output, {"scale": "1777x999"});
    sd.profile_save("ajuste_uno", output);
    assert sd.profile_names(output) == ["ajuste_uno"];
    sd.update(output, {"scale": "1920x1080"});
    custom, standard, unused = sd.scale_sections(output, sd.saved_settings(sd.config_read(), "TEST-1"));
    assert custom == ["1777x999", "1600x800"], (custom, standard, unused);
    assert standard == ["1920x1080"], (custom, standard, unused);
    assert unused == ["1500x850"], (custom, standard, unused);
    labels = sd.scale_grouped_labels(output, sd.saved_settings(sd.config_read(), "TEST-1"));
    assert len([row for row in labels if row[1] is None]) >= 5, labels;
    before = list(sd.history_for(sd.config_read(), "TEST-1"));
    assert sd.profile_load("ajuste_uno", output)["scale"] == "1777x999";
    assert sd.history_for(sd.config_read(), "TEST-1")[0] == "1777x999";
    assert all("--mode" not in command for command in calls);
    assert sd.profile_names(output) == ["ajuste_uno"];
    print("OK: perfiles, tres grupos MRU, definiciones sin usar, separadores, escala física intacta");
