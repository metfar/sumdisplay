# sumdisp 0.1a04 — comodidad visual

Aplicación X11/RandR de uso personal, con CLI y diálogos **sumTUI** y **sumGUI**.

## Instalación

```bash
install -m755 sumdisp ~/bin/sumdisp
cd ~/bin
ln -sfn sumdisp disp
ln -sfn sumdisp pantalla
ln -sfn sumdisp ajustaBrillo
ln -sfn sumdisp setBright
```

- `sumdisp --gui`: interfaz gráfica **sumGUI/Pygame** (`sumgui.easy`). No utiliza Tkinter.
- `sumdisp --tui`: diálogos **sumTUI** (`sumtui.dialogs`).
- `sumdisp status`, `sumdisp scale 1800x900`, `sumdisp gamma .8:.85:.95`, `sumdisp setbright .8`.
- `disp grande|delgada|normal`, `ajustaBrillo .8`, `setBright .8`.
- `sumdisp save lectura`, `sumdisp load lectura`.

En las interfaces, la resolución física solo se muestra como información; únicamente se cambia el escalado lógico. El CLI histórico `mode` continúa por compatibilidad.

**Cambio de 0.1a04:** la GUI tiene botones independientes para aplicar escala, brillo y gamma; al cambiar la escala no toma el brillo/gamma de los cuadros de edición. Primero ajusta geometría, después reaplica gamma/brillo guardados, y realiza una segunda aplicación de color tras una espera. Un cambio de escala requiere confirmación en 15 segundos y el intento se revierte al vencer el plazo.

**Calibración inicial por máquina**:

```bash
# Máquina grande
sumdisp gamma .8:.85:.95
# Máquina chica
sumdisp gamma .7:.7:.65
```

La configuración se guarda en `~/.config/sumdisp/config.json`, diferenciada por equipo y salida. La detección utiliza `xrandr --query`.

**Limitaciones:** no se ha probado el renderizado gráfico ni el comportamiento XRandR sobre hardware real desde este entorno. `sumdisp` no puede reconstruir cambios externos de gamma/brillo que no fueron guardados por él. Las confirmaciones gráficas pueden verse afectadas por cambios drásticos de escalado; conservá acceso a un terminal para `disp normal`.
