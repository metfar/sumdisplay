# sumdisp 0.1a05

GUI sumGUI: selector de escala lógica mediante `DialogSpec` y deslizadores para brillo, gamma R/G/B.
TUI sumTUI: `ComboBox` y `Slider` nativos, con flechas de teclado.
Modo físico solo lectura.

**Precaución:** ejecutar primero `sumdisp status` y guardar una configuración conocida con `sumdisp save estable`.

La vista GUI todavía requiere prueba en X11; el formulario combo de sumGUI utiliza un botón que recorre las opciones.

## 0.1a06: selector gráfico de resolución lógica

La GUI utiliza un ComboBox basado en `sumgui.widgets.Widget`, con ventana
modal desplegada, lista de hasta siete filas y barra de desplazamiento.
Soporta selección con ratón, rueda, barra arrastrable y teclado
(↑/↓, Inicio/Fin, RePág/AvPág, Intro y Esc). El modo físico permanece
solo de lectura y no cambia al seleccionar una escala lógica.

La selección del combo queda pendiente hasta pulsar «Aplicar», como los sliders.
La interfaz TUI se conserva sin cambios. La prueba sintáctica se realizó sin
un servidor X11 ni pygame instalados en el entorno de construcción.
