# sumdisp 0.1a01 (prototipo funcional)

Administrador de salida X11/RandR, pensado para comodidad visual. Un ejecutable Python y enlaces simbólicos opcionales.

## Instalar

```bash
install -m 755 sumdisp "$HOME/bin/sumdisp"
cd "$HOME/bin"
ln -sfn sumdisp pantalla
ln -sfn sumdisp disp
ln -sfn sumdisp ajustaBrillo
ln -sfn sumdisp setBright
```

Requiere Python 3 y `xrandr`, instalado normalmente con `x11-xserver-utils` en Debian/Ubuntu. La interfaz gráfica experimental requiere `python3-tk`. No funciona como controlador de monitores nativos Wayland.

**Antes del primer uso en cada máquina, registrar la gamma adecuada:**

```bash
# En la grande
sumdisp gamma .8:.85:.95
# En la chica (ejecutar en ESA máquina)
sumdisp gamma .7:.7:.65
```

Los ajustes se almacenan por nombre de host y salida en `~/.config/sumdisp/config.json` (o `$XDG_CONFIG_HOME/sumdisp/config.json`). Si todavía no se registró gamma, el valor provisional de compatibilidad es `0.7:0.7:0.65`; se recomienda registrarla explícitamente en cada equipo.

## Uso

```bash
sumdisp status
sumdisp list
sumdisp --output HDMI-2 status
sumdisp gamma .8:.85:.95
sumdisp setbright .8
ajustaBrillo .8
setBright .8
disp grande              # xrandr --scale-from 1920x1080
disp delgada             # xrandr --scale-from 1800x900
disp normal              # xrandr --scale 1x1
sumdisp mode 1600x900    # cambia modo físico: solo modos anunciados
sumdisp scale 1800x900
sumdisp save lectura
sumdisp load lectura
sumdisp --tui            # menú de texto sencillo
sumdisp --gui            # ventana Tk experimental
sumdisp --cli            # estado
```

`sumdisp` sin argumentos abre el menú de terminal si se ejecuta con TTY; de otro modo informa el estado. El nombre `pantalla` usa la misma lógica. `restore`/`normal` solamente devuelve la escala a 1:1; `reset` restaura escala 1:1, gamma 1:1:1 y brillo 1.0 de forma explícita.

## Notas de diseño

- Detección prioriza salida primaria activa; si no la hay, la primera activa, y luego la primera conectada.
- Se aplica **modo físico, después escala, y siempre gamma/brillo al final**.
- Los perfiles registran el modo físico actualmente anunciado y los últimos valores de escala/gamma/brillo **aplicados por sumdisp**, que pueden diferir del estado efectivo si se usó otro programa.
- Los perfiles se guardan en `~/.config/sumdisp/profiles/`.
- La ventana Tk ofrece confirmación de 15 segundos antes de conservar una modificación. El menú textual y la CLI aún **no** tienen reversión automática; usarlos con modos conocidos.
- `--gui` es una interfaz Tk de transición, **no es sumGUI**; `--tui` es un menú de texto, **no es sumTUI**. Para la integración nativa hacen falta las API reales de ambos proyectos. El motor ya es independiente de las vistas.
- No se realiza calibración ICC ni control del brillo físico del panel; `xrandr --brightness` actúa en software.
- Se recomienda comenzar por `status`, después definir gamma y brillo, y finalmente guardar un perfil.

## Licencia

GNU GPL v2 o posterior (encabezado incluido en el script).

## 0.1a02 – Corrección provisional

- El motor evita reenviar el modo físico si no ha cambiado.
- Evita reenviar el escalado si coincide con el registrado.
- Tras un cambio de escala espera 250 ms antes de reponer gamma y brillo.
- Prueba simulada: escala nueva → gamma propia → brillo anterior.
- **Pendiente:** validación en X11 real y sustitución de las interfaces provisionales
  de texto/Tkinter por diálogos nativos de sumTUI y sumGUI.
- El estado persistido describe los cambios hechos por sumdisp; no debe
  considerarse una lectura fidedigna de modificaciones externas a xrandr.

## 0.1a03 — enfoque de comodidad visual

- Resolución física: **solo lectura en las interfaces**; se detecta automáticamente.
- `--tui` utiliza diálogos nativos de `sumtui.dialogs` (`choose_menu`, `read_entry`, `show_message`), no `input()`.
- `--gui` mantiene temporalmente Tkinter hasta verificar el contrato de sumGUI; elimina el selector de modo físico.
- Al cargar perfiles antiguos, se ignora expresamente el campo `mode` para no alterar la resolución física.
- Los comandos CLI históricos (`disp`, `ajustaBrillo`, `setBright`) continúan disponibles. `mode` sigue siendo comando CLI explícito por compatibilidad; no se ofrece en los diálogos.
- No se ha probado en una pantalla X11 real. La confirmación temporal de la interfaz Tk sigue siendo provisional.
