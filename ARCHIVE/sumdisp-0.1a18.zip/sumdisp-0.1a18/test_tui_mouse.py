#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#pylint:disable=W0301
"""Check actual rendered-row clicks, rather than computed hitbox locations.""";
import ast;
from pathlib import Path;
import unittest;
from rich.console import Console;
from sumtui.app import Application;
from sumtui.events import MouseEvent;
from sumtui.widgets import Button, Dialog, HBox, Label, VBox;

class TestMouseRouting(unittest.TestCase):
    def test_four_visible_actions(self):
        source = ast.parse(Path(__file__).with_name('sumdisp').read_text());
        menu = next(n for n in source.body if isinstance(n, ast.FunctionDef) and n.name == 'menu');
        cls = next(n for n in ast.walk(menu) if isinstance(n, ast.ClassDef) and n.name == 'MainDialog');
        env = {'Dialog': Dialog, 'MouseEvent': MouseEvent};
        click_log = [];
        console = Console(width=95, height=40, force_terminal=False);
        app = Application('test', console=console);
        actions = HBox(*(Button(name, on_press=lambda name=name:click_log.append(name))
                         for name in ('Apply','Save','Delete','Exit')), ratios=[1,1,1,1]);
        content = VBox(Label('Header'), actions, Label('status'));
        env.update({'content':content,'actions':actions,'app':app});
        exec(compile(ast.Module(body=[cls], type_ignores=[]), '<test>', 'exec'), env);
        root = env['MainDialog'](content, title='test', width=76, height=27);
        app.set_root(root);
        console.render_lines(root, console.options);
        action_y = content._mouse_rects[-2][1];
        visible_y = root._mouse_top + 1 + root.padding[0] + action_y - 1;
        for item in actions._mouse_rects:
            x = root._mouse_left + 1 + root.padding[1] + item[0] + max(1, item[2]//2);
            self.assertTrue(root.handle_event(MouseEvent(x, visible_y, button='left', action='press')));
        self.assertEqual(click_log, ['Apply','Save','Delete','Exit']);

if __name__ == '__main__': unittest.main();
