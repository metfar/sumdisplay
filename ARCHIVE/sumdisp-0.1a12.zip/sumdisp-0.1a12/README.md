# sumdisp 0.1a12

Basado en sumdisp 0.1a10. Requiere las bibliotecas SUM compatibles con 0.1a10.

- Etiqueta `Perfil: NAME` o `Perfil: Actual`, sin textbox persistente en el formulario principal.
- Persistencia del último perfil guardado/cargado por host y salida en `config.json`.
- Guardar perfil abre diálogo con lista de existentes, nombre editable, Guardar y Cancelar.
- Confirmación antes de sobrescribir en TUI y GUI.
- Cargar perfil abre diálogo de selección.
- Guardar perfil guarda la **última configuración aplicada**, no los valores sin aplicar de sliders.
- No cambia la resolución física.

Nota GUI: la versión actual de `sumgui.dialogs.form_box` representa los campos combo
mediante un botón que recorre opciones. El desplegable nativo sigue disponible para
resoluciones en la ventana principal; la unificación completa del selector de perfiles
con el combo desplegable requiere extender `form_box` en sumGUI.
