import importlib.machinery, importlib.util, tempfile, json
from pathlib import Path
p=str(Path(__file__).resolve().parent/'sumdisp')
loader=importlib.machinery.SourceFileLoader('sumdisp_test13',p)
spec=importlib.util.spec_from_loader(loader.name,loader)
m=importlib.util.module_from_spec(spec)
loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
 m.CONFIG_DIR=Path(td)
 m.CONFIG_FILE=Path(td)/'config.json'
 m.PROFILES_DIR=Path(td)/'profiles'
 output={'name':'eDP-1-1','mode':'1366x768','modes':['1366x768'],'primary':True}
 m.config_write({'displays': {m.key_for(output['name']): {'scale':'1600x800','brightness':0.8,'gamma':[.7,.7,.65]}},'active_profiles':{}})
 assert m.profile_entries(output)[0] == ('Actual',m.PROFILE_ACTUAL,'option')
 assert m.matched_profile(output) is None
 m.profile_save('lectura',output)
 assert m.matched_profile(output)=='lectura'
 assert m.profile_names(output)==['lectura']
 c=m.config_read();c['displays'][m.key_for(output['name'])]['brightness']=1.1;m.config_write(c)
 assert m.matched_profile(output) is None
 assert m.profile_entries(output)==[('Actual',m.PROFILE_ACTUAL,'option'),('lectura','lectura','option')]
 print('Tests: initial Actual; persisted match; profiles; divergence -> Actual: OK')
