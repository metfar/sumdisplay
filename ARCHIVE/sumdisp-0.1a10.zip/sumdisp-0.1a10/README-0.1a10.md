# SUM widgets / sumdisp 0.1a10

The source packages are derived from the three archives provided by the user in this conversation.
No GitHub repository has been modified.

## Correcciones
- sumTUI: `ComboBox` real (en `sumtui.widgets.dropdown`) con selección mediante Espacio, Intro, flecha abajo o clic; diálogo sumTUI con lista, búsqueda, scrollbar lógico, y secciones no seleccionables.
- sumGUI: componente `sumgui.combobox_ext.ComboBox` disponible desde el paquete; Slider acepta `compact=True` con barra y valor en una sola fila, sin título interno.
- sumUI: se preserva el `ComboModel` y `valid_cell_character` incluidos en la versión corregida del usuario; ambos backends consumen el mismo modelo.
- sumdisp 0.1a10: usa ambos ComboBox compartidos y sliders compactos, sin widgets desplegables locales. Resolución física de solo lectura.

## Instalación de las bibliotecas (entorno de desarrollo)
Descomprimir los tres ZIP y, dentro de cada directorio, instalar sus dependencias y el paquete según su propia configuración. Por ejemplo, en un entorno virtual:
`python3 -m pip install -e ./sumui -e ./sumtui -e ./sumgui`

Después instalar `sumdisp` en PATH. `sumdisp --tui` requiere un terminal y `sumdisp --gui` un entorno gráfico compatible con pygame.

## Verificación
Se verificó compilación de fuentes, pruebas simuladas de estado de sumdisp e importación y construcción del desplegable sumTUI.
No se verificó sumGUI en ejecución: `pygame` no está instalado en este entorno; tampoco hay X11 para probar cambios de escala.

## Limitaciones y evolución
El modal sumTUI usa la lista nativa existente, no una copia gráfica. Los backends comparten semántica con `ComboModel`, pero sus representaciones son adaptadas a la capacidad de cada backend.
La búsqueda interactiva admite filtrado; una implementación completamente editable con validación visual idéntica en ambos backends todavía requiere pruebas y refinamientos.
