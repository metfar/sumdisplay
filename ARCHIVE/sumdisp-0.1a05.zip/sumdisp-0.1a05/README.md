# sumdisp 0.1a05

GUI sumGUI: selector de escala lógica mediante `DialogSpec` y deslizadores para brillo, gamma R/G/B.
TUI sumTUI: `ComboBox` y `Slider` nativos, con flechas de teclado.
Modo físico solo lectura.

**Precaución:** ejecutar primero `sumdisp status` y guardar una configuración conocida con `sumdisp save estable`.

La vista GUI todavía requiere prueba en X11; el formulario combo de sumGUI utiliza un botón que recorre las opciones.
