#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#pylint:disable=W0301
import ast;
from pathlib import Path;
import unittest;
from rich.console import Console;
from sumtui.events import MouseEvent;
from sumtui.widgets import Button, Dialog, HBox, Label, VBox;

class TestMouseRouting(unittest.TestCase):
    def test_three_actions(self):
        source = ast.parse(Path(__file__).with_name('sumdisp').read_text());
        menu = next(n for n in source.body if isinstance(n, ast.FunctionDef) and n.name == 'menu');
        cls = next(n for n in ast.walk(menu) if isinstance(n, ast.ClassDef) and n.name == 'ClickableActions');
        code = compile(ast.Module(body=[cls], type_ignores=[]), '<actions>', 'exec');
        env = {'HBox': HBox, 'Button': Button, 'MouseEvent': MouseEvent};
        exec(code, env);
        hit = [];
        actions = env['ClickableActions'](Button('Apply', on_press=lambda:hit.append('Apply')), Button('Save', on_press=lambda:hit.append('Save')), Button('Exit', on_press=lambda:hit.append('Exit')), ratios=[1, 1, 1]);
        root = Dialog(VBox(Label('test'), actions), title='test', width=76, height=16);
        console = Console(width=95, height=28);
        console.render_lines(root, console.options);
        row_top = root.child._mouse_rects[-1][1];
        y = root._mouse_top + 1 + root.padding[0] + row_top;
        for item in actions._mouse_rects:
            x = root._mouse_left + 1 + root.padding[1] + item[0] + max(1, item[2] // 2);
            self.assertTrue(root.handle_event(MouseEvent(x, y, button='left', action='press')));
        self.assertEqual(hit, ['Apply', 'Save', 'Exit']);

if __name__ == '__main__':
    unittest.main();
