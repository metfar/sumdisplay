# sumdisp 0.1a12

Basado en sumdisp 0.1a10. Requiere las bibliotecas SUM compatibles con 0.1a10.

- Etiqueta `Perfil: NAME` o `Perfil: Actual`, sin textbox persistente en el formulario principal.
- Persistencia del último perfil guardado/cargado por host y salida en `config.json`.
- Guardar perfil abre diálogo con lista de existentes, nombre editable, Guardar y Cancelar.
- Confirmación antes de sobrescribir en TUI y GUI.
- Cargar perfil abre diálogo de selección.
- Guardar perfil guarda la **última configuración aplicada**, no los valores sin aplicar de sliders.
- No cambia la resolución física.

Nota GUI: la versión actual de `sumgui.dialogs.form_box` representa los campos combo
mediante un botón que recorre opciones. El desplegable nativo sigue disponible para
resoluciones en la ventana principal; la unificación completa del selector de perfiles
con el combo desplegable requiere extender `form_box` en sumGUI.

## 0.1a13: disposición del formulario

En ambas interfaces, el selector de perfiles se encuentra arriba, con un botón «Cargar» al lado. La selección por sí sola **no aplica** ningún perfil. «Actual» significa que no hay un perfil guardado asociado con valores coincidentes. Debajo se encuentran escala lógica, brillo y gamma; al final, «Aplicar», «Guardar» y «Salir».

«Guardar» abre el diálogo de guardado, con nombre editable y confirmación al sobrescribir. Al guardar o cargar, el selector superior se actualiza. El cambio de escala lógica no modifica la resolución física del monitor. Las pruebas incluidas verifican el estado del perfil y la validez sintáctica; la interacción TUI/GUI necesita una prueba real con las versiones SUM instaladas.

## 0.1a14 — perfil activo persistente

Al pulsar Aplicar sin cambiar los parámetros, se conserva el nombre del perfil
activo en `active_profiles`. Si los valores aplicados ya no coinciden con el
perfil, se desasocia y se muestra Actual. Al cerrar y volver a entrar, se
recupera el perfil si sigue coincidiendo. No se cambia el modo físico.

## 0.1a15 — Diálogos de guardado corregidos e instalador

- En TUI, al abrir «Guardar perfil», el nombre editable se inicializa con el
  perfil seleccionado, incluso si no se produjo evento `on_change`.
- Al seleccionar otro nombre en el ComboBox TUI, se copia al campo editable.
- En GUI, «Guardar perfil» utiliza `sumgui.combobox_ext.ComboBox`: una lista
  desplegable con búsqueda y scrollbar, no el selector cíclico de `form_box`.
  Cambiar la selección actualiza inmediatamente el campo Nombre del perfil.
- Guardar un nombre existente requiere confirmación de sobrescritura.
- Se preserva la instalación como ejecutable único, además de proporcionar
  empaquetado Python como `sumdisplay`.

### Instalar sin pip

```sh
./install.sh
# Opcional: ./install.sh --aliases
```

Por defecto se instala `~/bin/sumdisp`; `SUMDISP_BIN_DIR` permite cambiarlo.
El instalador no reemplaza otros ejecutables preexistentes cuando se solicitan
alias opcionales.

### Instalar con pip

```sh
python3 -m pip install --user --no-deps --no-build-isolation .
```

O `./install.sh --pip`. Para Ubuntu con PEP 668, se recomienda el instalador
independiente o un entorno virtual. Si `pip` está bloqueado, no se modifica
la instalación de Python del sistema.

El paquete publica `sumdisp`, `sumdisplay`, `disp`, `pantalla`, `setBright`
y `ajustaBrillo` como comandos. La interfaz TUI/GUI requiere instalaciones
compatibles de sumUI, sumTUI y sumGUI. CLI requiere `xrandr` y una sesión X11.

La sintaxis, pruebas lógicas y creación de rueda (`wheel`) se verifican en
entorno de desarrollo. Las ventanas requieren prueba real con Pygame/X11.

## Novedades 0.1a16

- El diálogo GUI conserva título y etiquetas: los dibuja después del panel.
- Botón **Eliminar** en los diálogos de perfiles TUI y GUI; requiere confirmación.
- `sumdisp delete-profile NOMBRE` elimina un perfil desde CLI.
- Eliminar un perfil NO cambia la escala, el brillo ni la gamma aplicados.
- Si el perfil eliminado estaba activo, el selector pasa a «Actual».


### Language and multiple displays (0.1a17)

Use `sumdisp --tui --language en`, `sumdisp --gui --lang fr`, or
`sumdisp --tui --lang es`. English is the default. When more than one
active output is found, use the top **Display** dropdown to select one.
Settings and profile identity remain separate for each output.

The three bottom TUI buttons now route mouse events through their cell
layout, without changing the native keyboard event handling.
