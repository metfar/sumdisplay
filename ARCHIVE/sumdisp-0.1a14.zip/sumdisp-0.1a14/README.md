# sumdisp 0.1a12

Basado en sumdisp 0.1a10. Requiere las bibliotecas SUM compatibles con 0.1a10.

- Etiqueta `Perfil: NAME` o `Perfil: Actual`, sin textbox persistente en el formulario principal.
- Persistencia del último perfil guardado/cargado por host y salida en `config.json`.
- Guardar perfil abre diálogo con lista de existentes, nombre editable, Guardar y Cancelar.
- Confirmación antes de sobrescribir en TUI y GUI.
- Cargar perfil abre diálogo de selección.
- Guardar perfil guarda la **última configuración aplicada**, no los valores sin aplicar de sliders.
- No cambia la resolución física.

Nota GUI: la versión actual de `sumgui.dialogs.form_box` representa los campos combo
mediante un botón que recorre opciones. El desplegable nativo sigue disponible para
resoluciones en la ventana principal; la unificación completa del selector de perfiles
con el combo desplegable requiere extender `form_box` en sumGUI.

## 0.1a13: disposición del formulario

En ambas interfaces, el selector de perfiles se encuentra arriba, con un botón «Cargar» al lado. La selección por sí sola **no aplica** ningún perfil. «Actual» significa que no hay un perfil guardado asociado con valores coincidentes. Debajo se encuentran escala lógica, brillo y gamma; al final, «Aplicar», «Guardar» y «Salir».

«Guardar» abre el diálogo de guardado, con nombre editable y confirmación al sobrescribir. Al guardar o cargar, el selector superior se actualiza. El cambio de escala lógica no modifica la resolución física del monitor. Las pruebas incluidas verifican el estado del perfil y la validez sintáctica; la interacción TUI/GUI necesita una prueba real con las versiones SUM instaladas.

## 0.1a14 — perfil activo persistente

Al pulsar Aplicar sin cambiar los parámetros, se conserva el nombre del perfil
activo en `active_profiles`. Si los valores aplicados ya no coinciden con el
perfil, se desasocia y se muestra Actual. Al cerrar y volver a entrar, se
recupera el perfil si sigue coincidiendo. No se cambia el modo físico.
