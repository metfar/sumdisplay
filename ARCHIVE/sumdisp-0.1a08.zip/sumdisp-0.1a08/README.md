# sumdisp 0.1a08

Versión incremental basada en el `sumdisp` modificado por el usuario (rango de brillo -5 a +5).

## Nuevo en 0.1a08

- Selector de **escala lógica**, sin modificar la resolución física.
- Casilla «Mostrar catálogo de resoluciones», inicialmente desactivada, tanto en sumTUI como en sumGUI.
- Casilla desactivada: historial MRU (*most recently used*) de escalas aplicadas satisfactoriamente, específico por equipo y salida. Se guarda como `resolution_history` dentro de `~/.config/sumdisp/config.json`.
- Casilla activada: catálogo **local, curado y no exhaustivo** de resoluciones comunes, con etiqueta descriptiva (VGA, QHD, Full HD, etc.). Orden descendente por cantidad de píxeles, luego ancho y alto.
- `Default` representa exclusivamente escala original 1:1 (`--scale 1x1`), no una resolución física de un píxel.
- Cambiar de vista no aplica ninguna escala: la acción «Aplicar» es independiente.
- En sumGUI la lista mantiene navegación por rueda del mouse, barra de desplazamiento, teclado y selección directa. En sumTUI se utiliza el `ComboBox` disponible en el toolkit.
- Conserva límites de brillo -5 a +5 definidos por el usuario.

## Instalación

```bash
unzip sumdisp-0.1a08.zip
install -m755 sumdisp-0.1a08/sumdisp ~/bin/sumdisp
sumdisp --tui
sumdisp --gui
```

## Verificación sin pantalla

```bash
python3 sumdisp-0.1a08/test_resolution_history.py
```

## Alcances y pendientes

- Los valores de la lista son **dimensiones lógicas**; no se presentan como modos físicos garantizados.
- El catálogo local no pretende listar todos los estándares de resolución existentes.
- El ComboBox nativo de sumTUI actualmente es una selección no editable; la edición con búsqueda, validación y ampliación de catálogo pertenece a la evolución de sumUI/sumTUI/sumGUI.
- Esta revisión no modifica los paquetes de bibliotecas SUM ni implementa todavía temas configurables por CLI.
- La interfaz gráfica y los cambios XRandR reales requieren prueba en el sistema del usuario; los tests incluidos simulan XRandR.
- La lógica de reversión temporizada de la GUI es la heredada de 0.1a07; no fue rediseñada en esta revisión.
