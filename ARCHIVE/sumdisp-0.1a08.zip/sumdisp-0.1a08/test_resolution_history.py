#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#pylint:disable=W0301
#
#  Copyright 2018- William Martinez Bas <metfar@gmail.com>
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#
import importlib.machinery;
import importlib.util;
import pathlib;
import tempfile;

source = pathlib.Path(__file__).with_name("sumdisp");
loader = importlib.machinery.SourceFileLoader("sumdisp_test_module", str(source));
spec = importlib.util.spec_from_loader(loader.name, loader);
module = importlib.util.module_from_spec(spec);
loader.exec_module(module);
with tempfile.TemporaryDirectory() as directory:
    module.CONFIG_FILE = pathlib.Path(directory) / "config.json";
    output = {"name": "TEST-1", "mode": "1366x768", "modes": ["1366x768"], "primary": True};
    calls = [];
    module.xrandr = lambda *args: calls.append(args) or "";
    module.time.sleep = lambda unused: None;
    assert module.scale_normalize("Default") == "1x1";
    assert module.scale_label("1x1").startswith("Default");
    assert module.scale_from_label(module.scale_label("1920x1080")) == "1920x1080";
    assert module.scale_options(output, {"scale": "1x1"}) == ["1x1"];
    assert module.catalog_options()[0] == "7680x4320";
    pixels = [int(w) * int(h) for w, h in (item.split("x") for item in module.catalog_options())];
    assert pixels == sorted(pixels, reverse=True);
    module.update(output, {"scale": "1920x1080"});
    module.update(output, {"scale": "1800x900"});
    module.update(output, {"brightness": 0.8});
    assert module.history_for(module.config_read(), "TEST-1") == ["1800x900", "1920x1080"];
    module.update(output, {"scale": "1920x1080"});
    assert module.history_for(module.config_read(), "TEST-1") == ["1920x1080", "1800x900"];
    module.update(output, {"scale": "Default"});
    assert module.history_for(module.config_read(), "TEST-1")[0] == "1x1";
    assert all("--mode" not in group for group in calls);
    print("OK: catálogo, MRU, Default, brillo independiente y ausencia de cambios de modo físico");
